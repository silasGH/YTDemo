//
//  YTDirectionView.h
//  SecurityGuarder
//
//  Created by iBahs on 17/3/24.
//  Copyright © 2017年 iBahs. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YTDirectionView;

typedef enum : NSUInteger {
    YTDirection_unknow,
    YTDirection_up = 1,
    YTDirection_right_up = 2,
    YTDirection_right = 3,
    YTDirection_right_down = 4,
    YTDirection_down = 5,
    YTDirection_left_down = 6,
    YTDirection_left = 7,
    YTDirection_left_up = 8
} YTDirection;

@protocol YTDirectionViewProtocol <NSObject>

- (void)directionViewTouchBegan:(YTDirectionView *)directionView;
- (void)directionView:(YTDirectionView *)directionView touchingWithDirection:(YTDirection)direction;
- (void)directionViewTouchEnd:(YTDirectionView *)directionView;

@end

@interface YTDirectionView : UIView

@property (nonatomic, weak) id<YTDirectionViewProtocol> delegate;

/** 转换为指令,并输出方向(调试用) */
- (NSString *)cmdWithDirection:(YTDirection)direction;

@end
