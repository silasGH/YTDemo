//
//  NSObject+DS.m
//  DSDemos
//
//  Created by 宋利军 on 16/2/3.
//  Copyright © 2016年 Derek. All rights reserved.
//

#import "NSObject+DS.h"

@implementation NSObject (DS)

#define pi 3.14159265358979323846
#define degreesToRadian(x) (pi * x / 180.0)
#define radiansToDegrees(x) (180.0 * x / pi)

+ (CGFloat)distanceBetweenPoint1:(CGPoint)point1
                          point2:(CGPoint)point2 {
    CGFloat deltaX = point2.x - point1.x;
    CGFloat deltaY = point2.y - point1.y;
    return sqrt(deltaX*deltaX + deltaY*deltaY);
}

+ (CGFloat)angleBetweenLinesWithLine1Start:(CGPoint)line1Start
                                  line1End:(CGPoint)line1End
                                line2Start:(CGPoint)line2Start
                                  line2End:(CGPoint)line2End {
    CGFloat a = line1End.x - line1Start.x;
    CGFloat b = line1End.y - line1Start.y;
    CGFloat c = line2End.x - line2Start.x;
    CGFloat d = line2End.y - line2Start.y;
    CGFloat rads = acos(((a*c) + (b*d)) / ((sqrt(a*a + b*b)) * (sqrt(c*c + d*d))));
    return radiansToDegrees(rads);
}

@end
