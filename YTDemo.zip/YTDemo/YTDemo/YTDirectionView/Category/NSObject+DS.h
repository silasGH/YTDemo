//
//  NSObject+DS.h
//  DSDemos
//
//  Created by 宋利军 on 16/2/3.
//  Copyright © 2016年 Derek. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSObject (DS)

/** 计算两点之间的距离 */
+ (CGFloat)distanceBetweenPoint1:(CGPoint)point1
                          point2:(CGPoint)point2;

/** 计算一个圆内,两条线之间的角度 */
+ (CGFloat)angleBetweenLinesWithLine1Start:(CGPoint)line1Start
                                  line1End:(CGPoint)line1End
                                line2Start:(CGPoint)line2Start
                                  line2End:(CGPoint)line2End;

@end
