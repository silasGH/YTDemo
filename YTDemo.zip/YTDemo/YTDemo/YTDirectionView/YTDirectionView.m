//
//  YTDirectionView.m
//  SecurityGuarder
//
//  Created by iBahs on 17/3/24.
//  Copyright © 2017年 iBahs. All rights reserved.
//


#import "YTDirectionView.h"

#import "NSObject+DS.h"

@interface YTDirectionView ()

@property (weak, nonatomic) IBOutlet UIImageView *selectImageView;
@property (weak, nonatomic) IBOutlet UIImageView *centerRedImageView;
@property (weak, nonatomic) IBOutlet UIImageView *controlImageView;

@end

@implementation YTDirectionView

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    
    self.selectImageView.hidden = NO;
    self.centerRedImageView.hidden = YES;
    self.controlImageView.hidden = NO;
    
    if ([self.delegate respondsToSelector:@selector(directionViewTouchBegan:)]) {
        [self.delegate directionViewTouchBegan:self];
    }
    
    [self moveControlImageWithTouches:touches];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesMoved:touches withEvent:event];
    
    [self moveControlImageWithTouches:touches];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesEnded:touches withEvent:event];
    
    self.selectImageView.hidden = YES;
    self.centerRedImageView.hidden = NO;
    self.controlImageView.hidden = YES;
    //清空之前的transform
    self.controlImageView.layer.transform = CATransform3DIdentity;
    
    if ([self.delegate respondsToSelector:@selector(directionViewTouchEnd:)]) {
        [self.delegate directionViewTouchEnd:self];
    }
}

- (void)moveControlImageWithTouches:(NSSet<UITouch *> *)touches {
    CGPoint currentP = [self pointWithTouches:touches];
    BOOL isValidPoint = [self distanceCenterBetweenPoint:currentP];
    if (isValidPoint == YES) {
        [self rotateControlImage];
        
        CGFloat angle = [self angleWithPoint:currentP];
        YTDirection direction = [self directionWithAngle:angle];
        if ([self.delegate respondsToSelector:@selector(directionView:touchingWithDirection:)]) {
            [self.delegate directionView:self touchingWithDirection:direction];
        }
        
        //旋转操控杆
        self.controlImageView.layer.transform = CATransform3DRotate(self.controlImageView.layer.transform, -((M_PI_2 / 90) * angle), 0, 0, 1);
    }
}

//把操控杆旋转至零度的位置
- (void)rotateControlImage {
    self.controlImageView.layer.anchorPoint = CGPointMake(0.5, 1);
    self.controlImageView.layer.position = CGPointMake(self.bounds.size.width / 2, self.bounds.size.height / 2);
    self.controlImageView.layer.bounds = CGRectMake(0, 0, self.bounds.size.width * 0.37, self.bounds.size.height * 0.47);
    self.controlImageView.layer.transform = CATransform3DMakeRotation(M_PI_2, 0, 0, 1);
}

#pragma mark - 工具类方法
// 获取触摸点
- (CGPoint)pointWithTouches:(NSSet *)touches {
    UITouch *touch = [touches anyObject];
    return  [touch locationInView:self];
}

//获取当前点和圆心之间的距离
- (BOOL)distanceCenterBetweenPoint:(CGPoint)point {
    //0.53:是圆心到空白之间的距离/半径
    CGFloat minDistance = (self.bounds.size.width / 2) * 0.53;
    CGFloat maxDistance = self.bounds.size.width / 2;
    
    CGPoint center = CGPointMake(self.bounds.size.width / 2, self.bounds.size.height / 2);
    CGFloat distance = [[self class] distanceBetweenPoint1:center point2:point];
    
    if ((distance < maxDistance) && (distance > minDistance)) {
        return YES;
    }
    return NO;
}

//根据点的位置计算点的角度
- (CGFloat)angleWithPoint:(CGPoint)point {
    CGPoint line1Start = CGPointMake(self.bounds.size.width / 2, self.bounds.size.height / 2);
    CGPoint line1End = CGPointMake(self.bounds.size.width, self.bounds.size.height / 2);
    CGFloat angle = [[self class] angleBetweenLinesWithLine1Start:line1Start
                                                         line1End:line1End
                                                       line2Start:line1Start
                                                         line2End:point];
    if (point.y <= line1Start.y) {//一二象限
        return angle;
    } else {
        if ((point.x >= line1Start.x) && (point.y >= line1Start.y)) {//第四象限
            return (360.0 - angle);
        } else {//第三象限
            return ((180.0 - angle) + 180.0);
        }
    }
    return 0;
}

//根据角度计算点在什么方向
- (YTDirection)directionWithAngle:(CGFloat)angle {
    CGFloat angle1 = angle + 22.5;
    CGFloat num = angle1 / 45.0;
    NSInteger direction = (NSInteger)num;
    switch (direction) {
        case 0:
            return YTDirection_right;
            break;
        case 1:
            return YTDirection_right_up;
            break;
        case 2:
            return YTDirection_up;
            break;
        case 3:
            return YTDirection_left_up;
            break;
        case 4:
            return YTDirection_left;
            break;
        case 5:
            return YTDirection_left_down;
            break;
        case 6:
            return YTDirection_down;
            break;
        case 7:
            return YTDirection_right_down;
            break;
        case 8:
            return YTDirection_right;
            break;
        default:
            break;
    }
    return 0;
}

- (NSString *)cmdWithDirection:(YTDirection)direction {
    NSString *cmd = @"";
    switch (direction) {
        case YTDirection_right:
            cmd = @"touching-右";
            break;
        case YTDirection_right_up:
            cmd = @"touching-右上";
            break;
        case YTDirection_up:
            cmd = @"touching-上";
            break;
        case YTDirection_left_up:
            cmd = @"touching-左上";
            break;
        case YTDirection_left:
            cmd = @"touching-左";
            break;
        case YTDirection_left_down:
            cmd = @"touching-左下";
            break;
        case YTDirection_right_down:
            cmd = @"touching-右下";
            break;
        case YTDirection_down:
            cmd = @"touching-下";
            break;
        default:
            break;
    }
    return cmd;
}

@end
/*
CGFloat angleBetweenPoints(CGPoint first, CGPoint second) {
    CGFloat height = second.y - first.y;
    CGFloat width = first.x - second.x;
    CGFloat rads = atan(height/width);
    return radiansToDegrees(rads);
}
*/
