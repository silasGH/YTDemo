//
//  ViewController.m
//  YTDemo
//
//  Created by silas on 2018/3/9.
//  Copyright © 2018年 silas. All rights reserved.
//

#import "ViewController.h"
#import "YTDirectionView.h"

@interface ViewController ()
<
    YTDirectionViewProtocol
>
@property (nonatomic, weak) UILabel *lab;
@property (nonatomic, weak) YTDirectionView *directionView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    [self directionView];
    [self lab];
}

#pragma mark - YTControlViewProtocol
- (void)directionViewTouchBegan:(YTDirectionView *)directionView {
    self.lab.text = @"TouchBegan";
}

- (void)directionView:(YTDirectionView *)directionView touchingWithDirection:(YTDirection)direction {
    NSString *cmd = [directionView cmdWithDirection:direction];
    self.lab.text = cmd;
}

- (void)directionViewTouchEnd:(YTDirectionView *)directionView {
    self.lab.text = @"TouchEnd";
}

#pragma mark - setter and getter
- (YTDirectionView *)directionView {
    if (_directionView == nil) {
        YTDirectionView *directionView = [[[NSBundle mainBundle] loadNibNamed:@"YTDirectionView" owner:nil options:nil] firstObject];
        directionView.frame = CGRectMake(0, 0, 250, 250);
        directionView.center = self.view.center;
        directionView.delegate = self;
        [self.view addSubview:directionView];
        _directionView = directionView;
    }
    return _directionView;
}

- (UILabel *)lab {
    if (_lab == nil) {
        UILabel *lab = [[UILabel alloc] initWithFrame:CGRectMake(0, 20, [UIScreen mainScreen].bounds.size.width, 50.0)];
        lab.font = [UIFont systemFontOfSize:20.0];
        lab.backgroundColor = [UIColor lightTextColor];
        lab.textAlignment = NSTextAlignmentCenter;
        [self.view addSubview:lab];
        _lab = lab;
    }
    return _lab;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
